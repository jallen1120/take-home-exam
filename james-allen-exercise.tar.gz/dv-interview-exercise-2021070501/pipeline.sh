#!/bin/bash
# set -ex

# This script is a placeholder for a real CI/CD engine's pipeline.
# During the interview, this script will be used deploy the application inside your provided cluster
#
# This script can be used to call any other script, in any language
# Please, edit this script in any way you need so your deployment can be achieved

# Exercise related vars
#
# Please edit the following variables to target the project that was given to you.
CANDIDATE_NAME="james-allen"
DEV_IP="34.117.236.109"
PRD_IP="34.111.36.169"

GOOGLE_PROJECT="dv-${CANDIDATE_NAME}-1"
GOOGLE_REGION="us-central1"
GKE_CLUSTER_NAME="test-gke-cluster"
DEV_URL=http://dev.${DEV_IP}.sslip.io
PRD_URL=https://prd.${PRD_IP}.sslip.io

DOCKER_REGISTRY_ENDPOINT="us.gcr.io/${GOOGLE_PROJECT}"

export CANDIDATE_NAME GOOGLE_PROJECT GOOGLE_REGION GKE_CLUSTER_NAME DEV_URL PRD_URL DOCKER_REGISTRY_ENDPOINT
export GREEN=$'\e[0;32m' NC=$'\e[0m'

# The VERSION will be used in the STEP FOUR of the test
# Defaults to version 1.0.0 which correspond to the public Docker image available
VERSION="${1-1.0.0}"

#################################################################################################################################

# Step One
function step_one {
  # build the Hello Docker image
  #    Add the steps to build the Docker image of the Hello application
  #    from the provided Dockerfile
  # Logging into 
  echo "${GREEN}----- Building Docker image ${VERSION} -----${NC}"
  docker build -t ${DOCKER_REGISTRY_ENDPOINT}/hello:${VERSION} --build-arg VERSION=${VERSION} .
  echo "${GREEN}----- Successfully built image ${VERSION}. Now pushing image to ${DOCKER_REGISTRY_ENDPOINT} -----${NC}"
  docker push ${DOCKER_REGISTRY_ENDPOINT}/hello:${VERSION}
}

# Step Two
function step_two {
  # Deploy to dev namespace
  #    Add the commands to deploy the application in the `dev` namespace of the Kubernetes cluster
  #    After this step you should be able to reach the application at the http://dev.<HTTP ingress IP>.sslip.io URL
  
  # Connect to the specified cluster 
  echo "${GREEN}----- Starting step two. Deploying hello application to dev -----${NC}"
  gcloud container clusters get-credentials ${GKE_CLUSTER_NAME} --region ${GOOGLE_REGION} --project ${GOOGLE_PROJECT}

  # Update image to latest version
  echo "${GREEN}----- Updating dev deployment to use ${VERSION} -----${NC}"
  cd k8s/overlays/dev
  kustomize edit set image us.gcr.io/dv-james-allen-1/hello=us.gcr.io/dv-james-allen-1/hello:$VERSION
  cd -

  echo "${GREEN}----- Deployment has been successfully updated. Applying update to dev. -----${NC}"
  kubectl apply -k k8s/overlays/dev
  # Apply Dev overlay 
  # kubectl apply -k k8s/overlays/dev
  echo "${GREEN}----- Deployment to dev complete. The application will be available at ${DEV_URL}. NOTE: This can take up to 15 minutes to be available. -----${NC}"
}

# Step Three
function step_three {
  # Deploy to prd namespace
  #    Add the commands to deploy the application in the `prd` namespace of the Kubernetes cluster
  #    You will have to use an SSL certificate for this step (can be self-signed or cloud-generated, up to you)
  #    After this step you should be able to reach the application at the https://prd.<HTTPS ingress IP>.sslip.io URL
  
  # Connect to the specified cluster 
  echo "${GREEN}----- Starting step three. Deploying hello application to prd -----${NC}"
  gcloud container clusters get-credentials ${GKE_CLUSTER_NAME} --region ${GOOGLE_REGION} --project ${GOOGLE_PROJECT}

  # Update image to latest version
  echo "${GREEN}----- Updating prd deployment to use ${VERSION} -----${NC}"
  cd k8s/overlays/prd
  kustomize edit set image us.gcr.io/dv-james-allen-1/hello=us.gcr.io/dv-james-allen-1/hello:$VERSION
  cd -
  echo "${GREEN}----- Deployment has been successfully updated. Applying update to prd. -----${NC}"
  # Apply Prd overlay 
  kubectl apply -k k8s/overlays/prd
  echo "${GREEN}----- Deployment to prd complete. The application will be available at ${PRD_URL}. NOTE: This can take up to 15 minutes to be available. -----${NC}"
}

# Step Four
  # Use a dynamic version
  #    Update the 3 previous steps to support a dynamic version
  #    the VERSION variable is already defined. You set it by calling this script with a parameter:
  #    ./pipeline.sh 1.2.3   # set VERSION=1.2.3

step_one
step_two
step_three

# I used kustomize to template and build the Kubernetes resources. This decision was made largely in part of Step 4. Kustomize allows for overriding
# images out of the box very easily with `kustomize edit set image...` command. 
# To install kustomize, on MacOS, run `brew install kustomize`.
# If you don't have brew installed, see here: https://brew.sh

# I also used colors on every echo command to easily be able to differentiate the commands from their output.