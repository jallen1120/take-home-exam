# dv-interview-exercise
Exercise for DV interview, targeting DEV/OPS positions

This repo contains the exercise and the files to bootstrap the Candidate.

# Setup a new Candidate

## Generating the exercise.tar.gz file

From the root of this project, run the following command to create the `.tar.gz` file to send to the candidate:

```shell
tar zcvf dv-interview-exercise.tar.gz -C .. dv-interview-exercise/docs dv-interview-exercise/hello dv-interview-exercise/Dockerfile dv-interview-exercise/go.sum dv-interview-exercise/go.mod dv-interview-exercise/pipeline.sh
```

## Google Setup

This exercise will require a Kubernetes cluster and a Container (docker) registry.

Use the project [nytimes/dv-gcp-interview-projects](https://github.com/nytimes/dv-gcp-interview-projects) to boostrap a project with the needed features. Use the candidate's email to grant them access to the resources. Note that the Candidate's email MUST be a Google account email. If the candidate does not have one, ask them to register a google account with their personal email.

Once done, send back the information to the candidate along the project files so they can connect to the Gcloud project.
The informations should look something like:

```

TO: first.last@gmail.com

Welcome to the New York Times Hiring Take-Home Exercise.

Here are the informations you will need to access the Google Project.
Please, use the email address that you previously provided, `first.last@gmail.com`,  to connect to the Google console at https://console.cloud.google.com

Your Google project name is `dv-first-last-1`. You should see it in the `all` tabs when in the `select project` window.

Your Docker Registry URL is `us.gcr.io/dv-first-last-1/<your-image-name>:<version>`

Your Kubernetes cluster name is `test-gke-cluster`

IP address for HTTP ingress: 34.107.157.146
IP address for HTTPS ingress: 35.244.254.9

Please find the exercise in the attached `dv-interview-exercise.tar.gz` file.
```

## The Hello Applicaiton

Follow the doc at [Hello.md](docs/Hello.md) to fully understand how the Hello application works.

## The Exercise

Once you're setup and you've learnt about the Hello application, go through the [Exercise](docs/Exercise.md) documentation.
