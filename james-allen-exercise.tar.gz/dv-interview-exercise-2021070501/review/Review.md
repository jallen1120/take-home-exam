# Exercise Review

## General Questions

* how do you feel about this exercise ? How did it went ?
* do you think this exercise reflect a real life situation ? why ?
* do you see any missing piece or weakness in this application architecture ? (no SSL in the app itself, no persistence of data, no scalability possible as the count is not global, no test step in the pipeline)
* what would you change in the application or the deployment process to make it more cloud-native ? (cache the `count` values in a shared DB or backend app, use a message queue, use an API Gateway to split the prd en dev traffic, add shared authentication...)

## build a container image of the app

The candidate have to build and push the Docker image of the application into the local GCP Docker Registry.
As we're providing the Dockerfile, it should be a simple `docker build` and `docker push`.

### Checklist
1. is it building with Docker or another builder (kaniko, img ?)
1. was the `VERSION` argument set when building the application inside the image ?  (step 4 of the exercise)
1. when building, how is the image tag picked ? does it handle commit number ? tag ? Is it SemVer ? What each part of the version means ?

If the Candidate updated the Dockerfile:
1. is it using a multi-stage build (using an image for the build then another image with only the binary) ?
1. is it rootless (running as another user than root) ?
1. is it using stripped source image (distroless) or minimal (scratch, alpine) or full (centos, ubuntu) as final image base ?
1. does the Dockerfile provide a way to set the VERSION variables ?

### Question on the exercise

* explain the provided Dockerfile step by step ?
    - using a Golang image based on alpine to build the Go binary
    - we add the source code into the docker image
    - we run `go build` with some parameters to configure the target binary
    - we start a new image from Distroless, a stripped down image without any package manager or admin binaries, like no shell
    - we switch to a non-root user
    - we copy the previously build binary into this new image
    - we configure the image to start the binary first

* what is a multi-stage build in a Dockerfile ?
    - it's a way of using different images to build some artifacts that are later used in the final image. It make the resulting image smaller and get rid of all the build time dependencies, making it more secure.

* what are the basic docker commands you usually use on the commandline ?
    - pull: download an image from a remote registry
    - build: use a Dockerfile to create a new image
    - tag: add tags (or name) to the image
    - push: copy a local image into a remote registry
    - run: create/run a container from an image

* what is a rootless Docker image ? Why would you use it ?
    - rootless means it's running with a non-privileged user
    - a non-root container have a smaller blast surface in case a malicious user take control of it

* what are the common `base images` often used to build new Docker images ?
    - Alpine and scratch are often used for lightweight containers
    - usual Debian, Ubuntu, Centos images are used when you need a full features OS
    - Distroless is used when you your final image only contain a single binary

* can you describe the difference between stripped source image (distroless) or minimal (scratch, alpine) or full (centos, ubuntu) image base ?

### Digging Questions

* what is the Docker Daemon used for ?
* explain Docker In Docker ?
* what are Container Runtimes ? Do you know one ? (Docker, containerd, CRI-O, https://www.padok.fr/en/blog/container-docker-oci)
* kubernetes 1.21 is getting rid of Docker support. What does that means ?
* what is the difference between ARG and ENV in a Dockerfile ?
* is it bad to use `latest` image tag ? why ?

### Assessment

#### strong yes
  The candidate:
  - is fluent with Docker (containers) concept
  - knows the structure of a Dockerfile and common commands used in it
  - know the different ways to build an image and to push it into a Registry
  - know how to login to different kind of Registries (GCR, ECR, dockerhub...)
  - knows about alternatives ways to build Docker images (Kaniko, IMG, BuildX)

#### yes

  The candidate:
  - is able to create a Dockerfile from scratch, build the image and publish it
  - is using external variables (ARG) set at build time

#### mixed

  The candidate:
  - is able to create a simple Dockerfile
  - is not using distroless or rootless images
  - did not set VERSION from a variables at build time

#### no

  The candidate:
  - wasn't able to copy the public image into the project's registry
  - wasn't able to build the Docker image from the provided Dockerfile
  - can't explain basic Dockerfile keywords, like `entrypoint`, `cmd`, or does not undestand the multi-stage build concept

#### strong no

  - The Candidate does not show any knowledge of Docker and Containers

## Deployment to Kubernetes

### Checklist

1. are the deployment files built as a template, with values to deploy in the `dev` and `prd` namespace in the same cluster ?
1. is the target cluster part of the template too ?
1. is the service port exposed in the deployment ?
1. are the ports named in the deployment ? in the service ? are ports shared by name or port number ?
1. is the health endpoint used for probes ? both liveness and readiness ?
1. how are the limits / requests setup ? why ?
1. is the deployment made using a persistent volume to store the state data ? (not used in this exercise)
1. is the deployment using it's own ServiceAccount ? is it the same SA for both `dev` and `prd` ? What does it change ?
1. how is the scaling of the app set ? Usage of Horizontal Pod Autoscaler ?

### Question on the exercise

* explain the role of each Kubernetes Resource in your deployment ?
* what commands would you use to debug an issue with your workload ?
* can you explain what's happening when your pod is crash-looping with imagePullBackoff error ?
* when would you use annotations on a workload ?
* how did you defined the values of the `limits` in your Deployment ? Why ?
* what kind of `probes` can be set to ensure your pod is running ? (tcp, http, exec)
* what is a horizontal pod autoscaler ? How is it working ?
* what can be used to scale the number of nodes automatically ?
* what is the difference between Terraform and Kubernetes ? (bumb question, Kubernetes is a "workload orchestrator" while TF is a tool for infrastructure as code)
* why did you used `this tool` to template your deployment ? (being Helm, Kustomize, Envsubst...)

### Digging Questions

* how do you user K8s RBAC ? What are the Resources involved in their creation ? (Role/ClusterRole and RoleBinding/ClusterRoleBinding)
* what are the differences between a `deployment`, a `statefulset` and a `daemonset` ? What do they have in common ?
* how can you validate the Resources YAML before deploying them ? (kubectl --dry-run=client)
* What is a PV ? a PVC ? how do they work together ?
* What are the differences between Helm and Kustomize ?
* What are the two roles that a node can play in a K8s cluster ? What are the different components running in a Master Node (or Control Plane) and a Worker Nodes ?
* Can you explain the role of the `kubelet` process ?
* Explain how you can control the network traffic between pods inside a k8s cluster (Network Policies when using the right CNI)
* What is a K8s Operator ?
* Explain the role of the Admission Controler (Mutating/Validating Webhooks) ?
* what is `Workload Identity` when using K8s in the cloud ? (linking a K8s SA to a Cloud SA)

### Assessment

#### strong yes

- All files are templated using a common tool like Kustomize, Jsonnet or Helm
- The candidate have a clear understanding of each K8s resource and how they work together with the API
- The deployment use its own ServiceAccount and the candidate have a strong knowledge of security applied to K8s
- An `infrastructure as code` tool (Terraform) is used to gather some cluster informations needed for deployment

#### yes

- The files are templated and allows for further templating down the line. The templating system is simple to use and extend
- The structure of the templates shows a clear understanding of K8s Resources
- The candidate is able to explain how the different resources work, like difference between pods,jobs,daemonset,statefulsets,deployments

#### mixed

- The templating system is based on multiple tools like sed, awk and it is difficult to extend the templates
- The candidate knows very little of K8s internals and resources

#### no

- Temapltes are not rendering well and can't be deployed
- The candidate does not demonstrate a clear understanding of K8s

#### strong no

- No templating, the yamls are duplicated for each env
- Almost no knowledge of K8s reources and tools

## Ingress to reach the app

The candidate needs to create an ingress with HTTPS so application can be reached from outside

### Checklist

1. which ingress controller was used (can be default GKE controler or any existing, nginx, haproxy, envoy/istio/ambassador/gloo, traefik) ? How the Candidate made its decision ?
1. where is the SSL certificate coming from ? Is it self-signed ? auto-renewed ?


### Question on the exercise

* what is the difference between an `Ingress` and a Service of type `LoadBalancer` ?
* have you ever used a non-standard Ingress Controler ? Why did you chosed that one ?
* can you explain the workflow of an HTTPS connexion ?

### Digging Questions

* how would you add authentication to the application without changing it ?
* explain how the traffic is load-balanced between pods inside the cluster ?
* can we consider an `Ingress` Controler as an API Gateway ?
* how could a Service Mesh help to manage traffic in a cluster ? What are the benefits/tradeoff of a Service Mesh ?

### Assessment

#### strong yes

- Used a non-default Ingress Controler. Knows about dynamic SSL (Let's Encrypt).
- The Candidate knows about K8s CNI and the underlying network of a k8s cluster, knows the differences between different cloud providers offering of K8s
- The Candidate know about Service Mesh, sidecars and authentication proxies.

#### yes

The candidate:
- Set up a working Ingress for each environment, with SSL certificates
- Have clear knowledge about the networking in a K8s cluster and the different ways to connect to the cluster from outside

#### mixed

The candidate:
- Set up a working Ingress or public access made with `LoadBalancer` services
- Is not able to describe the traffic flow from client to pod
- Does not know any Ingress controler beside GKE
- Did not set up an SSL Ingress

#### no

- No working Ingress traffic supported
- No clear understanding of Network within a K8s cluster

#### strong no

- No working Ingress
- Does not know about Ingress Controlers

## CI/CD script

The candidate has to build a `pipeline` script that simulates a CI/CD to create the infra and deploy the app.
While we won't judge which language / tool was used, we want to understand the reasons of picking one.

### Checklist

1. which language is used ? why ?
1. is there a clear difference between the CI (build) and the CD (deployment) part ?
1. how do you pass the env variables (dev/prd, external name, cluster endpoint, SSL cert) to the script ?
1. is the deployment working ? if no, why ?

### Question on the exercise

* which CI/CD tool do you know ? Have you used one in a production environment ?
* how would you describe the difference between CI and CD ?
* explain how your `pipeline.sh` script is working ?
* would you change something in your deployment script if you had to scale this project to million requests per seconds and had unlimited resources and time ?

### Digging Questions

* what would you change to support A/B deployment of the application ?
* if using a real CI/CD tool, how would you split the tasks in a Directed Acyclic Graph ? Which parts would you run in parallel ?

### Assessment

#### strong yes

- Terraform or Gcloud commands are used to validate the infra (cluster, docker registry, external IPs) and grab some information that is later used for the deployment
- The Candidate have knowledge of different CI/CD tools and know the difference between them
- The Candidate know about Kubernetes tools like Argo or Flux, that are based on K8s Resources

#### yes

- The script is structured so it can be used in a CI/CD tool "as is"
- the script is using variables to mimick the informations coming from the Git commits and pipeline triggers

#### mixed

- The script is bulky and not documented, but deployment is working

#### no

- The script is not working
- The same script is not built to run against dev and prd environments

#### strong no

- The script is not UNIX standard and needs a lot of exotic tooling to work
- Documentations does not help to get the script running
- The Candidate does not have much knowledge of CI/CD ecosystem and concepts
